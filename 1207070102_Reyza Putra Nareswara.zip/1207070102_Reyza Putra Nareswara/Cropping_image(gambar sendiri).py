#Import Library
import matplotlib.pyplot as plt

from skimage import data
from skimage.io import imread
from skimage.color import rgb2gray
from skimage.util import invert
import numpy as np

#==============================
#Percobaan 1 : cropping image
#Meload data gambar bumblebee dan optimus
bee = plt.imread("Bumblebee.jpeg")
opt = plt.imread("OptimusP.jpg")

#Cropping gambar astronaut dan camera
# Membuat variabel beeCropped dan optCropped yang mereferensikan pada variabel bee dan opt
beeCropped = bee.copy()
optCropped = opt.copy()
# Memotong bagian tertentu dari gambar beeCropped dan optCropped
beeCropped = beeCropped[0:256,64:320]
optCropped = optCropped[64:256,128:320]

#Menampilkan resolusi dari gambar astrounaut asli dan hasil crop
print('Bumblebee Ori Shape : ',bee.shape)
print('Bumblebee Crop Shape : ',beeCropped.shape)
#Menampilkan resolusi dari gambar camera asli dan hasil crop
print('Optimus Ori Shape : ',opt.shape)
print('Optimus Crop Shape : ',optCropped.shape)
#Membuat bingkai untuk menampilkan gambar astronaut dan camera asli serta hasil cropping nya

# Membuat figure dengan ukuran 2x2 subplots dengan ukuran 12x12 inch
fig, axes = plt.subplots(2, 2, figsize=(12, 12))
# Menyatakan variabel ax yang merupakan akses ke subplots dalam bentuk 1 dimensi
ax = axes.ravel()
# Menampilkan gambar pertama (bee) pada ax[0] dan memberi judul
ax[0].imshow(bee)
ax[0].set_title("Citra input 1")
# Menampilkan gambar kedua (opt) pada ax[1] dan memberi judul
ax[1].imshow(opt)
ax[1].set_title("Citra input 2")
# Menampilkan gambar bee yang sudah dipotong pada ax[2] dan memberi judul
ax[2].imshow(beeCropped)
ax[2].set_title("Citra output 1")
# Menampilkan gambar opt yang sudah dipotong pada ax[3] dan memberi judul
ax[3].imshow(optCropped)
ax[3].set_title("Citra output 2")
# Mengatur jarak antar subplot agar rapih
fig.tight_layout()

#Menampilkan gambar secara keseluruhan
plt.show()

#==============================
#Percobaan 2 - Citra Negatif

#Citra negatif astronaut

#Membuat variabel yg berisi inversi warna dari gambar astronaut yang sudah di crop
inv = invert(beeCropped)
#Menampilkan resolusi gambar asli dan hasil inversi
print('Shape Input : ', beeCropped.shape)
print('Shape Output : ',inv.shape)
#Membuat bingkai untuk menampilkan gambar astronaut yang sudah di crop dan histogramnya, 
# serta gambar hasil inversi warna dan histogramnya
# membuat figure dengan 4 subplot (2x2) dengan ukuran 12x12
fig, axes = plt.subplots(2, 2, figsize=(12, 12))
# meratakan array axes menjadi sebuah array 1 dimensi
ax = axes.ravel()
# menampilkan gambar pertama pada subplot pertama
ax[0].imshow(beeCropped)
# memberi judul pada subplot pertama
ax[0].set_title("Citra Input")
# menampilkan histogram citra input pada subplot kedua
ax[1].hist(beeCropped.ravel(), bins=256)
# memberi judul pada subplot kedua
ax[1].set_title('Histogram Input')
# menampilkan gambar hasil inversi pada subplot ketiga
ax[2].imshow(inv)
# memberi judul pada subplot ketiga
ax[2].set_title('Citra Output (Inverted Image)')
# menampilkan histogram citra output pada subplot keempat
ax[3].hist(inv.ravel(), bins=256)
# memberi judul pada subplot keempat
ax[3].set_title('Histogram Output')

# menyesuaikan tata letak gambar agar tampilan frame terlihat lebih rapi dan proporsional
fig.tight_layout()

#Menampilkan gambar secara keseluruhan
plt.show()

#Citra negatif camera
# mengubah citra menjadi grayscale
gray = rgb2gray(optCropped) 
print('img2gray shape = ',gray.shape) 

#Membuat variabel untuk mengcopy gambar camera
optCopy = gray.copy().astype(float)
#Membuat variabel untuk ukuran citra
# Mengambil dimensi matriks optCopy
m1, n1 = optCopy.shape
# Membuat array kosong dengan ukuran m1 x n1
output1 = np.empty([m1, n1])
# Looping untuk setiap elemen pada matriks optCopy
for baris in range(0, m1-1):
    for kolom in range(0, n1-1):
        # Mengambil koordinat a1 dan b1 dari elemen yang sedang diiterasi
        a1 = baris
        b1 = kolom
        # Menambahkan nilai 2 pada elemen yang sedang diiterasi dan menyimpan hasilnya pada output1
        output1[a1, b1] = optCopy[baris, kolom] + 2

#Membuat bingkai untuk menampilkan gambar camera asli dan histogramnya
# serta gambar hasil inversi warna dan histogramnya        
# Membuat subplots dengan ukuran 2x2 dan ukuran total gambar sebesar 12x12
fig, axes = plt.subplots(2, 2, figsize=(12, 12))
# Membuat array satu dimensi dari objek axes
ax = axes.ravel()
# Menampilkan citra gray dalam subplot pertama
ax[0].imshow(gray, cmap = 'gray')
ax[0].set_title("Citra Input")
# Menampilkan histogram dari citra optCropped dalam subplot kedua
ax[1].hist(optCropped.ravel(), bins=256)
ax[1].set_title('Histogram Input')
# Menampilkan citra hasil brightening pada subplot ketiga
ax[2].imshow(output1, cmap = 'gray')
ax[2].set_title('Citra Output (Brightnes)')
# Menampilkan histogram dari citra hasil brightening pada subplot keempat
ax[3].hist(output1.ravel(), bins=256)
ax[3].set_title('Histogram Output')

#Menampilkan gambar secara keseluruhan
plt.show()