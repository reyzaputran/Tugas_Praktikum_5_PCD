#Import Library
import matplotlib.pyplot as plt

from skimage import data
from skimage.io import imread
from skimage.color import rgb2gray
from skimage.util import invert
import numpy as np

#==============================
#Percobaan 1 : cropping image

#Meload data gambar camera dan astronaut dari skimage
astronautImage = data.astronaut()
cameraImage = data.camera()
#Cropping gambar astronaut dan camera
astroCropped = astronautImage.copy()
astroCropped = astroCropped[0:256,64:320]
cameraCropped = cameraImage.copy()
cameraCropped = cameraCropped[64:256,128:320]
#Menampilkan resolusi dari gambar astrounaut asli dan hasil crop
print('Astro Ori Shape : ',astronautImage.shape) #Menampilkan resolusi gambar astronaut asli
print('Astro Crop Shape : ',astroCropped.shape) #Menampilkan resolusi gambar astronaut hasil cropping
#Menampilkan resolusi dari gambar camera asli dan hasil crop
print('Camera Ori Shape : ',cameraImage.shape) #Menampilkan resolusi gambar camera asli
print('Camera Crop Shape : ',cameraCropped.shape) #Menampilkan resolusi gambar camera hasil cropping

#Membuat bingkai untuk menampilkan gambar astronaut dan camera asli serta hasil cropping nya
# Membuat subplot 2x2 dengan ukuran 12x12
fig, axes = plt.subplots(2, 2, figsize=(12, 12))
# Melakukan flatten pada array axes
ax = axes.ravel()
# Menampilkan citra astronautImage pada axes[0] dan memberi judul "Citra input 1"
ax[0].imshow(astronautImage)
ax[0].set_title("Citra input 1")
# Menampilkan citra cameraImage pada axes[1] dengan colormap gray dan memberi judul "Citra input 2"
ax[1].imshow(cameraImage,cmap=plt.cm.gray)
ax[1].set_title("Citra input 2")
# Menampilkan citra astroCropped pada axes[2] dan memberi judul "Citra output 1"
ax[2].imshow(astroCropped)
ax[2].set_title("Citra output 1")
# Menampilkan citra cameraCropped pada axes[3] dengan colormap gray dan memberi judul "Citra output 2"
ax[3].imshow(cameraCropped, cmap=plt.cm.gray)
ax[3].set_title("Citra output 2")
# Mengatur layout gambar agar rapih
fig.tight_layout()
#Menampilkan gambar secara keseluruhan
plt.show()

#==============================
#Percobaan 2 - Citra Negatif

#Citra negatif astronaut

#Membuat variabel yg berisi inversi warna dari gambar astronaut yang sudah di crop
inv = invert(astroCropped)
#Menampilkan resolusi gambar asli dan hasil inversi
print('Shape Input : ', astroCropped.shape)
print('Shape Output : ',inv.shape)

#Membuat bingkai untuk menampilkan gambar astronaut yang sudah di crop dan histogramnya, 
# serta gambar hasil inversi warna dan histogramnya
# Membuat subplot 2x2 dengan ukuran 12x12
fig, axes = plt.subplots(2, 2, figsize=(12, 12))
# Melakukan flatten pada array axes
ax = axes.ravel()
# Menampilkan citra astroCropped pada axes[0] dan memberi judul "Citra Input"
ax[0].imshow(astroCropped)
ax[0].set_title("Citra Input")
# Menampilkan histogram dari citra astroCropped pada axes[1] dan memberi judul "Histogram Input"
ax[1].hist(astroCropped.ravel(), bins=256)
ax[1].set_title('Histogram Input')
# Menampilkan citra inv (inverted image) pada axes[2] dan memberi judul "Citra Output (Inverted Image)"
ax[2].imshow(inv)
ax[2].set_title('Citra Output (Inverted Image)')
# Menampilkan histogram dari citra inv pada axes[3] dan memberi judul "Histogram Output"
ax[3].hist(inv.ravel(), bins=256)
ax[3].set_title('Histogram Output')
# Mengatur layout gambar agar rapih
fig.tight_layout()
#Menampilkan gambar secara keseluruhan
plt.show()

#Citra negatif camera

# Membuat salinan dari citra cameraCropped dan mengubah tipe datanya menjadi float
copyCamera = cameraImage.copy().astype(float)
# Mendapatkan ukuran citra
m1, n1 = copyCamera.shape
# Membuat array kosong dengan ukuran yang sama dengan citra input
output1 = np.empty([m1, n1])
# Melakukan loop untuk setiap pixel pada citra
for baris in range(0, m1-1):
    for kolom in range(0, n1-1):
        # Mendapatkan koordinat pixel
        a1 = baris
        b1 = kolom        
        # Menambahkan nilai 100 ke nilai piksel pada citra input pada koordinat (a1, b1)
        output1[a1, b1] = copyCamera[baris, kolom] + 100


#Membuat bingkai untuk menampilkan gambar camera asli dan histogramnya
# serta gambar hasil inversi warna dan histogramnya        
# Membuat subplots dengan 2 baris dan 2 kolom serta ukuran 12x12
fig, axes = plt.subplots(2, 2, figsize=(12, 12))
# Mengubah array axes menjadi array 1 dimensi
ax = axes.ravel()
# Menampilkan citra input pada subplot pertama
ax[0].imshow(cameraCropped, cmap='gray')
ax[0].set_title("Citra Input")
# Menampilkan histogram citra input pada subplot kedua
ax[1].hist(cameraCropped.ravel(), bins=256)
ax[1].set_title('Histogram Input')
# Menampilkan citra output pada subplot ketiga
ax[2].imshow(output1, cmap='gray')
ax[2].set_title('Citra Output (Brightness)')
# Menampilkan histogram citra output pada subplot keempat
ax[3].hist(output1.ravel(), bins=256)
ax[3].set_title('Histogram Output')

#Menampilkan gambar secara keseluruhan
plt.show()