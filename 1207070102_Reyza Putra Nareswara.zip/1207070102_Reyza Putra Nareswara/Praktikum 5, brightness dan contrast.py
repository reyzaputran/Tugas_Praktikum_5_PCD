#import library
import numpy as np
import imageio
import cv2 as cv
import matplotlib.pyplot as plt

#Load gambar
img = cv.imread("Bumblebee.jpeg")

#Mendapatkan/define resolusi dan tipe gambar
img_height = img.shape[0]  # mengambil nilai dimensi ketinggian citra
img_width = img.shape[1]  # mengambil nilai dimensi lebar citra
img_channel = img.shape[2]  # mengambil jumlah channel dari citra
img_type = img.dtype  # mengambil tipe data dari citra (e.g. uint8, float32, dll)

#==============================================
#BRIGHTNESS

#Percobaan pertama kita buat brightness untuk gambar grayscale
#Membuat variabel img_brightness untuk menampung

img_brightness = np.zeros(img.shape, dtype = np.uint8)

#Membuat fungsi penambahan brightness dengan nilai yang menjadi parameter
def brighter(nilai):
    for y in range(0, img_height):  # loop untuk setiap baris citra
        for x in range(0, img_width):  # loop untuk setiap kolom citra
            red = img[y][x][0]  # mengambil nilai pixel merah pada koordinat (x, y)
            green = img[y][x][1]  # mengambil nilai pixel hijau pada koordinat (x, y)
            blue = img[y][x][2]  # mengambil nilai pixel biru pada koordinat (x, y)
            # konversi citra menjadi grayscale
            gray = (int(red) + int(green) + int(blue))/3  
            gray += nilai  # menambahkan nilai kecerahan
            if gray > 255:  # jika nilai kecerahan melebihi 255 (nilai maksimum)
                gray = 255  # set nilai kecerahan menjadi 255
            if gray < 0:  # jika nilai kecerahan kurang dari 0 (nilai minimum)
                gray = 0  # set nilai kecerahan menjadi 0
            img_brightness[y][x] = (gray, gray, gray)  # update nilai pixel citra pada koordinat (x, y)

#Menampilkan gambar grayscale dengan parameter kecerahan -100
brighter(-100) #Kecerahan dikurang sebanyak 100
cv.imshow('Brightness -100',img_brightness)
cv.waitKey(0)# Perintah agar pengguna dapat menutup jendela popup dengan tombol keyboard
cv.destroyAllWindows()# Menutup semua jendela popup yg terbuka

#Menampilkan gambar grayscale dengan parameter kecerahan +25
brighter(25) #Kecerahan ditambah sebanyak 25
cv.imshow('Brightness +25',img_brightness)
cv.waitKey(0)# Perintah agar pengguna dapat menutup jendela popup dengan tombol keyboard
cv.destroyAllWindows()

#brightness RGB
img_rgbbright = np.zeros(img.shape, dtype = np.uint8)

#Fungsi untuk brightness RGB dengan nilai parameter 
def rgbbrighter(nilai):
    for y in range(0, img_height):
        for x in range(0, img_width):
            red = img[y][x][0]  # mengambil nilai komponen merah di pixel (x,y)
            red += nilai  # menambahkan nilai kecerahan pada komponen merah
            if red > 255:  # membatasi nilai ke maksimum 255
                red = 25
            if red < 0:  # membatasi nilai ke minimum 0
                red = 0
            green = img[y][x][1]  # mengambil nilai komponen hijau di pixel (x,y)
            green += nilai  # menambahkan nilai kecerahan pada komponen hijau
            if green > 255:  # membatasi nilai ke maksimum 255
                green = 255
            if green < 0:  # membatasi nilai ke minimum 0
                green = 0
            blue = img[y][x][2]  # mengambil nilai komponen biru di pixel (x,y)
            blue += nilai  # menambahkan nilai kecerahan pada komponen biru
            if blue > 255:  # membatasi nilai ke maksimum 255
                blue = 255
            if blue < 0:  # membatasi nilai ke minimum 0
                blue = 0
            img_rgbbright[y][x] = (red, green, blue)  # menyimpan nilai RGB yang telah diubah pada posisi (x,y)


#Menampilkan gambar RGB dengan parameter kecerahan -100
rgbbrighter(-100)
cv.imshow('Brightness -100',img_rgbbright)
cv.waitKey(0)# Perintah agar pengguna dapat menutup jendela popup dengan tombol keyboard
cv.destroyAllWindows()

#Menampilkan gamabr RGB dengan parameter kecerahan +25
rgbbrighter(25)
cv.imshow('Brightness +25',img_rgbbright)
cv.waitKey(0)# Perintah agar pengguna dapat menutup jendela popup dengan tombol keyboard
cv.destroyAllWindows()

#=====================================
#CONTRAST

#Grayscale contrast
img_contrass = np.zeros(img.shape, dtype = np.uint8)

def contrass(nilai):
    # Looping per piksel pada citra
    for y in range(0, img_height):
        for x in range(0, img_width):
            # Dapatkan nilai intensitas warna merah, hijau, dan biru pada piksel
            red = img[y][x][0]
            green = img[y][x][1]
            blue = img[y][x][2]
            # Hitung nilai keabuan dengan rata-rata dari intensitas warna merah, hijau, dan biru
            gray = (int(red) + int(green) + int(blue))/3
            # Tambahkan nilai kontras ke nilai keabuan
            gray += nilai
             # Batasi nilai keabuan agar tidak lebih dari 255
            if gray > 255:
                gray = 255
            # Set nilai piksel pada citra output dengan nilai keabuan yang baru
            img_contrass[y][x] = (gray, gray, gray)

#Menampilkan gambar grayscale dengan parameter kontras +2
contrass(2)
cv.imshow('Contrass 2',img_contrass)
cv.waitKey(0)# Perintah agar pengguna dapat menutup jendela popup dengan tombol keyboard
cv.destroyAllWindows()

#Menampilkan gambar grayscale dengan parameter kontras +10
contrass(10)
cv.imshow('Contrass 10',img_contrass)
cv.waitKey(0)# Perintah agar pengguna dapat menutup jendela popup dengan tombol keyboard
cv.destroyAllWindows()

#RGB contrast
img_rgbcontrass = np.zeros(img.shape, dtype = np.uint8)
#Fungsi untuk contrass RGB dengan nilai parameter 
def rgbcontrass(nilai):
    # Looping setiap piksel pada citra
    for y in range(0, img_height):
        for x in range(0, img_width):
            red = img[y][x][0]
            # Menambahkan nilai kontras ke setiap nilai R, G, dan B
            red += nilai
            if red > 255:
                red = 255
            green = img[y][x][1]
            green += nilai
            if green > 255:
                green = 255
            blue = img[y][x][2]
            blue += nilai
            if blue > 255:
                blue = 255
            # Menyimpan nilai R, G, dan B yang baru pada piksel tertentu
            img_rgbcontrass[y][x] = (red, green, blue)


rgbcontrass(2)
cv.imshow('COntrass rgb 2',img_rgbcontrass)
cv.waitKey(0)# Perintah agar pengguna dapat menutup jendela popup dengan tombol keyboard
cv.destroyAllWindows()

rgbcontrass(10)
cv.imshow('Contrass rgb 10',img_rgbcontrass)
cv.waitKey(0)# Perintah agar pengguna dapat menutup jendela popup dengan tombol keyboard
cv.destroyAllWindows()

#=========================================
#AUTO LEVEL CONTRAST

#Contrast autolevel grayscale
img_autocontrass = np.zeros(img.shape, dtype = np.uint8)
#Mendefinisikan fungsi autocontrass untuk gambar grayscale
def autocontrass():
    # menginisialisasi variabel
    xmax = 255
    xmin = 0
    d = 0

    # mencari nilai maksimum dan minimum dari seluruh pixel gambar
    for y in range(0, img_height):
        for x in range(0, img_width):
            red = img[y][x][0]
            green = img[y][x][1]
            blue = img[y][x][2]
            gray = (int(red) + int(green) + int(blue))/3
            if gray < xmax:
                xmax = gray
            if gray > xmin:
                xmin = gray
                
    # menghitung nilai d
    d = xmin - xmax

    # melakukan kontras otomatis
    for y in range(0, img_height):
        for x in range(0, img_width):
            red = img[y][x][0]
            green = img[y][x][1]
            blue = img[y][x][2]
            gray = (int(red) + int(green) + int(blue))/3
            gray = int(float(255/d) * (gray - xmax))
            img_autocontrass[y][x] = (gray, gray, gray)


#Menampilkan gambar autolevel contrast grayscale
autocontrass()
cv.imshow('Auto level contrass',img_autocontrass)
cv.waitKey(0)# Perintah agar pengguna dapat menutup jendela popup dengan tombol keyboard
cv.destroyAllWindows()

#Contrast autolevel RGB
img_rgbautocontrass = np.zeros(img.shape, dtype = np.uint8)
#Mendefinisikan fungsi rgbautocontrass untuk gambar RGB
# Fungsi untuk melakukan auto-contrast pada gambar berwarna (RGB)
def rgbautocontrass():
    xmax = 255 # nilai maksimum untuk piksel
    xmin = 0 # nilai minimum untuk piksel
    d = 0 # selisih antara nilai maksimum dan minimum
    # mencari nilai maksimum dan minimum dari setiap warna piksel di gambar
    for y in range(0, img_height):
        for x in range(0, img_width):
            red = img[y][x][0]
            green = img[y][x][1]
            blue = img[y][x][2]             
            if red > xmax:
                xmax = red
            if green > xmax:
                xmax = green
            if blue > xmax:
                xmax = blue
            if red < xmin:
                xmin = red
            if green < xmin:
                xmin = green
            if blue < xmin:
                xmin = blue

    d = xmax - xmin # menghitung selisih antara nilai maksimum dan minimum
    # melakukan operasi auto-contrast pada setiap piksel
    for y in range(0, img_height):
        for x in range(0, img_width):
            red = img[y][x][0]
            green = img[y][x][1]
            blue = img[y][x][2]
            # menghitung nilai warna yang baru setelah auto-contrast
            red = int(float(255/d) * (red - xmin))
            green = int(float(255/d) * (green - xmin))
            blue = int(float(255/d) * (blue - xmin))
            img_rgbautocontrass[y][x] = (red, green, blue) # menyimpan piksel baru pada gambar hasil

#Menampilkan gambar autolevel contrast grayscale
rgbautocontrass()
cv.imshow('RGB Auto level contrass',img_rgbautocontrass)
cv.waitKey(0)# Perintah agar pengguna dapat menutup jendela popup dengan tombol keyboard
cv.destroyAllWindows()